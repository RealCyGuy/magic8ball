# magic8ball package

Gets a list of magic 8 ball responses.